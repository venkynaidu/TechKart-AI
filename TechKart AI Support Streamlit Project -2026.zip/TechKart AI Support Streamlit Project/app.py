import os
import json
import re
import time
from datetime import datetime

import pandas as pd
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from google import genai

st.set_page_config(
    page_title="TechKart AI Support Agent",
    page_icon="🤖",
    layout="wide"
)

# -----------------------------
# Configuration
# -----------------------------
st.title("🤖 TechKart AI Customer Support Agent")
st.caption("Generative AI + RAG + Tools + Memory + Agentic Workflow")

if "tickets" not in st.session_state:
    st.session_state.tickets = []

if "conversation" not in st.session_state:
    st.session_state.conversation = []

# -----------------------------
# Demo database
# -----------------------------
orders = {
    "ORD1001": {
        "customer": "Rahul",
        "product": "Laptop",
        "status": "Shipped",
        "expected_delivery": "2026-09-28",
        "amount": 65000
    },
    "ORD1002": {
        "customer": "Priya",
        "product": "Headphones",
        "status": "Delivered",
        "expected_delivery": "2026-09-25",
        "amount": 3500
    },
    "ORD1003": {
        "customer": "Arjun",
        "product": "Smartphone",
        "status": "Processing",
        "expected_delivery": "2026-10-02",
        "amount": 28000
    },
    "ORD1004": {
        "customer": "Sneha",
        "product": "Laptop",
        "status": "Delivered",
        "expected_delivery": "2026-09-27",
        "amount": 72000
    }
}

policies = {
    "delivery": """TechKart Delivery Policy:
Standard delivery normally takes 3 to 5 business days.
If an order is delayed beyond its expected delivery date, verify status.
If delayed by more than 2 business days, escalate for investigation.""",

    "refund": """TechKart Refund Policy:
Eligible customers can request refunds according to product terms.
Do not promise a refund before eligibility is verified.
High-value refund disputes require human review.""",

    "cancellation": """TechKart Cancellation Policy:
Cancellation may be possible before shipment.
After shipment, cancellation may not be possible.
Verify order status before confirming cancellation.""",

    "damaged": """TechKart Damaged Product Policy:
Damaged-product cases may require photographs or other evidence.
Replacement or investigation follows company procedure.
Do not promise replacement before verification.""",

    "warranty": """TechKart Warranty Policy:
Eligible products receive warranty support according to product terms.
Technical issues should be diagnosed before promising repair or replacement."""
}

policy_names = list(policies.keys())
policy_texts = list(policies.values())
vectorizer = TfidfVectorizer()
policy_vectors = vectorizer.fit_transform(policy_texts)


# -----------------------------
# Helpers
# -----------------------------
def get_client(api_key):
    return genai.Client(api_key=api_key)


def ask_ai(client, model, prompt, max_attempts=3):
    """
    Call Gemini with retries for temporary overload/rate/service errors.
    This does not change the selected model; it retries the same request.
    """
    last_error = None

    for attempt in range(max_attempts):
        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt
            )
            return response.text

        except Exception as exc:
            last_error = exc
            error_text = str(exc).lower()

            # Retry only likely transient service/overload errors.
            transient = (
                "503" in error_text
                or "unavailable" in error_text
                or "high demand" in error_text
                or "429" in error_text
                or "resource_exhausted" in error_text
                or "500" in error_text
                or "internal" in error_text
            )

            if not transient or attempt == max_attempts - 1:
                break

            # Backoff: 2 seconds, then 4 seconds.
            time.sleep(2 ** (attempt + 1))

    if last_error:
        error_text = str(last_error).lower()
        if "503" in error_text or "unavailable" in error_text or "high demand" in error_text:
            raise RuntimeError(
                f"Gemini model '{model}' is temporarily overloaded (503). "
                "The app retried automatically. Wait a minute and try again, "
                "or choose another model available to your API account in the sidebar. "
                f"Original details: {last_error}"
            ) from last_error
        raise last_error


def retrieve_policy(query, top_k=1):
    query_vector = vectorizer.transform([query])
    scores = cosine_similarity(query_vector, policy_vectors)[0]
    ranked = scores.argsort()[::-1][:top_k]

    return [
        {
            "policy": policy_names[i],
            "score": float(scores[i]),
            "text": policy_texts[i]
        }
        for i in ranked
    ]


def extract_order_id(text):
    match = re.search(r"ORD\d{4}", text.upper())
    return match.group(0) if match else None


def get_order_status(order_id):
    if not order_id:
        return None
    return orders.get(
        order_id.upper().strip(),
        {"error": f"Order {order_id} was not found."}
    )


def parse_json(raw):
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if not match:
        return {"raw_response": raw}
    try:
        return json.loads(match.group())
    except Exception:
        return {"raw_response": raw}


def analyze_ticket(client, model, message):
    prompt = f"""
You are a customer support classifier for TechKart.

Return ONLY valid JSON:
{{
  "category": "Delivery|Refund|Cancellation|Damaged Product|Wrong Product|Technical Support|Account|Other",
  "priority": "Low|Medium|High|Critical",
  "sentiment": "Positive|Neutral|Frustrated|Angry",
  "summary": "...",
  "order_id": "ORD#### or null",
  "requires_human": true/false
}}

Customer message:
{message}
"""
    return parse_json(ask_ai(client, model, prompt))


def create_ticket(customer, category, priority, message, order_id):
    ticket = {
        "ticket_id": f"TKT{len(st.session_state.tickets) + 1001}",
        "customer": customer,
        "category": category,
        "priority": priority,
        "message": message,
        "order_id": order_id,
        "status": "Open",
        "created_at": datetime.now().isoformat(timespec="seconds")
    }
    st.session_state.tickets.append(ticket)
    return ticket


def support_agent(client, model, customer_message, customer_name):
    analysis = analyze_ticket(client, model, customer_message)

    order_id = analysis.get("order_id") or extract_order_id(customer_message)
    order_info = get_order_status(order_id)
    policy = retrieve_policy(customer_message, 1)[0]

    ticket = create_ticket(
        customer_name,
        analysis.get("category", "Other"),
        analysis.get("priority", "Medium"),
        customer_message,
        order_id
    )

    decision_prompt = f"""
You are TechKart's support decision agent.

Use ONLY the supplied information.

Customer message:
{customer_message}

Ticket analysis:
{json.dumps(analysis, indent=2)}

Order information:
{json.dumps(order_info, indent=2)}

Relevant company policy:
{json.dumps(policy, indent=2)}

Return ONLY JSON:
{{
  "action": "Respond" or "Escalate",
  "reason": "...",
  "customer_response": "..."
}}

Rules:
- Never invent order details.
- Never promise a refund, replacement or cancellation unless supported.
- Follow the supplied policy.
- If information is insufficient, ask for the missing information.
- If the case is high risk, recommend human review.
"""

    decision = parse_json(ask_ai(client, model, decision_prompt))

    return {
        "analysis": analysis,
        "order_info": order_info,
        "policy": policy,
        "ticket": ticket,
        "decision": decision
    }


def evaluate_response(client, model, customer_message, response, context):
    prompt = f"""
You are a quality evaluator for TechKart customer support.

Customer:
{customer_message}

Proposed response:
{response}

Available context:
{json.dumps(context, indent=2)}

Check:
1. Relevance
2. Factual grounding
3. Policy compliance
4. No invented information
5. Professional tone

Return ONLY JSON:
{{
  "passed": true/false,
  "issues": [],
  "suggested_improvement": ""
}}
"""
    return parse_json(ask_ai(client, model, prompt))


def needs_human_review(analysis, order_info):
    if analysis.get("priority") in ["Critical", "High"]:
        return True

    if str(analysis.get("sentiment", "")).lower() == "angry":
        return True

    if isinstance(order_info, dict) and order_info.get("amount", 0) >= 60000:
        return True

    return False


# -----------------------------
# Sidebar
# -----------------------------
with st.sidebar:
    st.header("⚙️ Configuration")

    api_key = st.text_input(
        "Gemini API Key",
        type="password",
        help="Use an API key for the classroom/demo environment."
    )

    model = st.text_input(
        "Gemini Model",
        value="gemini-3.8-flash"
    )

    st.divider()

    st.subheader("🎓 Project Learning")
    st.write("• LLM / Prompt Engineering")
    st.write("• Structured JSON")
    st.write("• RAG")
    st.write("• Python Tools")
    st.write("• Agentic Workflow")
    st.write("• Memory")
    st.write("• Evaluation")
    st.write("• Human-in-the-loop")

    if st.button("🗑️ Clear Session"):
        st.session_state.tickets = []
        st.session_state.conversation = []
        st.rerun()


# -----------------------------
# Tabs
# -----------------------------
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "💬 Support Agent",
    "📚 RAG Knowledge Base",
    "🛠️ Tools & Orders",
    "🎫 Ticket Dashboard",
    "🎓 Student Challenge"
])


with tab1:
    st.header("💬 Customer Support Agent")

    col1, col2 = st.columns([1, 2])

    with col1:
        customer_name = st.text_input("Customer Name", value="Rahul")

    with col2:
        sample = st.selectbox(
            "Try a sample ticket",
            [
                "Custom message",
                "My laptop hasn't arrived yet. Expected delivery was yesterday. Order ORD1001.",
                "I received the wrong product. Order ORD1002.",
                "I want to cancel my smartphone order ORD1003.",
                "My laptop arrived damaged. Order ORD1004.",
                "My headphones stopped working after two weeks.",
                "I am extremely angry. Nobody is helping me!"
            ]
        )

    if sample == "Custom message":
        message = st.text_area(
            "Customer Message",
            height=140,
            placeholder="Type a real customer complaint..."
        )
    else:
        message = st.text_area(
            "Customer Message",
            value=sample,
            height=140
        )

    if st.button("🚀 Analyze & Resolve Ticket", type="primary"):
        if not api_key:
            st.error("Enter your Gemini API key in the sidebar.")
        elif not message.strip():
            st.warning("Enter a customer message.")
        else:
            with st.spinner("AI agent is analyzing the ticket..."):
                try:
                    result = support_agent(
                        get_client(api_key),
                        model,
                        message,
                        customer_name
                    )

                    st.session_state.last_result = result
                    st.session_state.conversation.append(
                        {"role": "customer", "message": message}
                    )

                except Exception as e:
                    error_text = str(e)
                    if "NOT_FOUND" in error_text or "no longer available" in error_text:
                        st.error(
                            "Gemini model not available to this API account. "
                            "Choose a model that your Gemini API account currently supports. "
                            f"Details: {error_text}"
                        )
                    elif "temporarily overloaded (503)" in error_text:
                        st.warning(
                            "Gemini is temporarily busy. The app retried automatically. "
                            "Please wait a minute and try again, or select another model "
                            "available to your API account in the sidebar."
                        )
                        with st.expander("Technical details"):
                            st.code(error_text)
                    else:
                        st.error(f"Error: {error_text}")

    if "last_result" in st.session_state:
        result = st.session_state.last_result

        st.divider()
        st.subheader("1️⃣ AI Ticket Analysis")

        a = result["analysis"]

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Category", a.get("category", "Unknown"))
        c2.metric("Priority", a.get("priority", "Unknown"))
        c3.metric("Sentiment", a.get("sentiment", "Unknown"))
        c4.metric("Order ID", a.get("order_id") or "Not found")

        st.info(a.get("summary", ""))

        st.subheader("2️⃣ Order Tool Result")
        st.json(result["order_info"])

        st.subheader("3️⃣ RAG — Retrieved Company Policy")
        st.write(f"**Policy:** {result['policy']['policy']}")
        st.write(f"**Similarity:** {result['policy']['score']:.3f}")
        st.code(result["policy"]["text"])

        st.subheader("4️⃣ Agent Decision")
        decision = result["decision"]
        action = decision.get("action", "Unknown")

        if action == "Escalate":
            st.warning("⚠️ Agent recommends HUMAN ESCALATION")
        else:
            st.success("✅ Agent can respond")

        st.write("**Reason:**", decision.get("reason", ""))

        st.subheader("5️⃣ Customer Response")
        st.chat_message("assistant").write(
            decision.get("customer_response", "No response generated.")
        )

        if needs_human_review(a, result["order_info"]):
            st.warning(
                "👨‍💼 Human-in-the-loop: this case should receive human review "
                "because of priority, sentiment, or order value."
            )

        st.subheader("6️⃣ AI Response Evaluator")

        if st.button("🔍 Evaluate Response"):
            with st.spinner("Evaluating response..."):
                try:
                    evaluation = evaluate_response(
                        get_client(api_key),
                        model,
                        message,
                        decision.get("customer_response", ""),
                        result
                    )

                    if evaluation.get("passed") is True:
                        st.success("✅ Response passed evaluation")
                    else:
                        st.error("⚠️ Response needs improvement")

                    st.json(evaluation)
                except Exception as e:
                    st.error(f"Evaluation error: {e}")


with tab2:
    st.header("📚 RAG Knowledge Base")

    st.write(
        "This demo uses TF-IDF retrieval to teach the RAG concept. "
        "In production, replace this with a vector database."
    )

    for name, text in policies.items():
        with st.expander(f"📄 {name.title()} Policy"):
            st.write(text)

    query = st.text_input(
        "Ask the knowledge base",
        placeholder="Example: Can I cancel an order that has shipped?"
    )

    if st.button("🔎 Retrieve Policy"):
        if query:
            results = retrieve_policy(query, 2)

            for r in results:
                st.write(f"### {r['policy'].title()}")
                st.write(f"Similarity score: `{r['score']:.3f}`")
                st.code(r["text"])


with tab3:
    st.header("🛠️ Tools & Orders")

    st.subheader("Order Database")
    st.dataframe(pd.DataFrame(orders).T, use_container_width=True)

    order_id = st.text_input("Order ID", value="ORD1001")

    if st.button("🔍 Run Order Lookup Tool"):
        st.json(get_order_status(order_id))

    st.divider()

    st.subheader("Available Agent Tools")
    st.code(
        """get_order_status(order_id)
retrieve_policy(query)
create_support_ticket(...)
escalate_to_human(...)"""
    )


with tab4:
    st.header("🎫 Support Ticket Dashboard")

    if st.session_state.tickets:
        df = pd.DataFrame(st.session_state.tickets)

        c1, c2, c3 = st.columns(3)
        c1.metric("Total Tickets", len(df))
        c2.metric("Open Tickets", len(df[df["status"] == "Open"]))
        c3.metric(
            "High/Critical",
            len(df[df["priority"].isin(["High", "Critical"])])
        )

        st.dataframe(df, use_container_width=True)

    else:
        st.info("No tickets created yet. Analyze a customer message first.")


with tab5:
    st.header("🎓 Student Mini-Hackathon")

    st.markdown("""
### Build your own AI Support Agent

**Teams**

1. 🚚 Delivery Agent
2. 💰 Refund Agent
3. 📦 Damaged Product Agent
4. 🔄 Wrong Product Agent
5. 🔧 Technical Support Agent
6. 😡 Angry Customer / Escalation Agent

### Required Features

- AI ticket classification
- Order ID extraction
- Python tool call
- RAG policy retrieval
- Agent decision
- Customer response
- AI response evaluator
- Human escalation

### Suggested timing

**40 minutes build + 20 minutes demo**

### Final demo

Each team gets 5 minutes to show:

**Customer → AI Analysis → Tool → RAG → Agent → Response → Evaluator → Human Escalation**
""")

st.divider()
st.caption("TechKart AI Support Agent — Educational Demonstration Project")
