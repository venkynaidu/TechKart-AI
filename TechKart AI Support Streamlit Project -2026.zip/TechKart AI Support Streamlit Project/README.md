# TechKart AI Customer Support Agent

A Streamlit educational project demonstrating:

- Generative AI
- Prompt Engineering
- Structured JSON
- RAG
- Python tools
- Agentic workflow
- Conversation state
- Response evaluation
- Human-in-the-loop

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

Open the URL shown by Streamlit, usually:

http://localhost:8501

## API Key

Enter your Gemini API key in the sidebar.

For production, use Streamlit secrets instead of entering keys in the UI.

## Classroom Project

Students can modify:

- policies
- order database
- tools
- categories
- agent prompts
- evaluator rules
- UI
- database integration

## Deployment

This project can be deployed to Streamlit Community Cloud, another cloud platform, or a server running Streamlit.
